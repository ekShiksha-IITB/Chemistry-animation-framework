function Linear() {
	this.type = "Linear" ;
	var group = new THREE.Group() ;
	
	var centeral = new THREE.Mesh(new THREE.SphereBufferGeometry(0.3, 32, 32),new THREE.MeshBasicMaterial({color : 0xFF1493}));

	var cylinder = new THREE.Mesh(new THREE.CylinderGeometry( 0.1, 0.1, 1.0, 32 ), new THREE.MeshBasicMaterial( {color: 0xFF1493} ));
	
	cylinder.rotation.z = Math.PI ;
	
	var edge_cylinder1 = new THREE.Mesh(new THREE.CylinderGeometry( 0.1, 0.1, 0.3, 32 ), new THREE.MeshBasicMaterial( {color: 0xffffff} ));
	
	edge_cylinder1.position.y += 0.6 ;

	var edge_cylinder2 = new THREE.Mesh(new THREE.CylinderGeometry( 0.1, 0.1, 0.3, 32 ), new THREE.MeshBasicMaterial( {color: 0xffffff} ));
	
	edge_cylinder2.position.y -= 0.6 ;
	
	var edge1 = new THREE.Mesh(new THREE.SphereBufferGeometry(0.3, 32, 32),new THREE.MeshBasicMaterial({color : 0xffffff}));
	edge1.position.y += 0.9 ;
	var edge2 = new THREE.Mesh(new THREE.SphereBufferGeometry(0.3, 32, 32),new THREE.MeshBasicMaterial({color : 0xffffff}));
	edge2.position.y -= 0.9 ;	
	group.add(centeral) ;
	group.add(cylinder) ;
	group.add(edge_cylinder1) ;
	group.add(edge_cylinder2) ;
	group.add(edge1) ;
	group.add(edge2) ;
	this.shape = group ;
}
